import React, { useEffect, useRef } from 'react';
import { Entity, EntityType, GameState, Particle, FloatingText } from '../types';
import { GAME_CONFIG, ENTITY_CONFIG } from '../constants';
import { audioService } from '../services/audioService';

interface GameCanvasProps {
  gameState: GameState;
  onScoreUpdate: (score: number) => void;
  onGameOver: (finalScore: number) => void;
  setInternalScore: (score: number) => void;
}

const GameCanvas: React.FC<GameCanvasProps> = ({ gameState, onScoreUpdate, onGameOver, setInternalScore }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  
  // Game State Refs (Mutable for performance)
  const entitiesRef = useRef<Entity[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const textsRef = useRef<FloatingText[]>([]);
  const scoreRef = useRef<number>(0);
  const lastSpawnTimeRef = useRef<number>(0);
  const spawnRateRef = useRef<number>(GAME_CONFIG.INITIAL_SPAWN_RATE);
  const mousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const batPosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const comboCountRef = useRef<number>(0);
  const lastKillTimeRef = useRef<number>(0);
  const isSwingingRef = useRef<boolean>(false);
  const swingTimerRef = useRef<number>(0);

  // Initialize mouse at center
  useEffect(() => {
    batPosRef.current = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    mousePosRef.current = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
  }, []);

  // Reset logic
  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      entitiesRef.current = [];
      particlesRef.current = [];
      textsRef.current = [];
      scoreRef.current = 0;
      setInternalScore(0);
      spawnRateRef.current = GAME_CONFIG.INITIAL_SPAWN_RATE;
      comboCountRef.current = 0;
      
      // Reset bat position
      batPosRef.current = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
    }
  }, [gameState, setInternalScore]);

  // Input Listeners
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePosRef.current = { x: e.clientX, y: e.clientY };
    };
    
    const handleMouseDown = () => {
        isSwingingRef.current = true;
        swingTimerRef.current = Date.now();
        audioService.playSwat();
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
    };
  }, []);

  // Main Loop
  const animate = (time: number) => {
    if (gameState !== GameState.PLAYING && gameState !== GameState.START) {
        // Even in game over, render static scene or freeze
        // But for this game, let's stop updating logic in Game Over
        if (gameState === GameState.GAME_OVER) return; 
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Responsive Canvas
    if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }

    // 1. Clear & Background
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw Jungle Gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, '#2d5a27'); // Deep green
    gradient.addColorStop(1, '#1a3c18'); // Darker green
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 2. Bat Movement (Lerp)
    const lerp = GAME_CONFIG.BAT_LAG;
    batPosRef.current.x += (mousePosRef.current.x - batPosRef.current.x) * lerp;
    batPosRef.current.y += (mousePosRef.current.y - batPosRef.current.y) * lerp;

    // Bat Angle for swing animation
    let batRotation = 0;
    if (isSwingingRef.current) {
        const elapsed = Date.now() - swingTimerRef.current;
        if (elapsed < 150) {
            batRotation = -Math.PI / 4 + (elapsed / 150) * (Math.PI / 2); // Swing arc
        } else {
            isSwingingRef.current = false;
        }
    } else {
        // Subtle tilt based on movement X
        batRotation = (mousePosRef.current.x - batPosRef.current.x) * 0.005;
    }

    if (gameState === GameState.PLAYING) {
        updateGameLogic(time, canvas);
    }

    drawParticles(ctx);
    drawEntities(ctx);
    drawFloatingText(ctx);
    drawBat(ctx, batPosRef.current.x, batPosRef.current.y, batRotation);

    requestRef.current = requestAnimationFrame(animate);
  };

  const updateGameLogic = (time: number, canvas: HTMLCanvasElement) => {
    // Spawning
    if (time - lastSpawnTimeRef.current > spawnRateRef.current) {
        spawnEntity(canvas);
        lastSpawnTimeRef.current = time;
        // Increase difficulty
        spawnRateRef.current = Math.max(GAME_CONFIG.MIN_SPAWN_RATE, spawnRateRef.current * GAME_CONFIG.DIFFICULTY_RAMP);
    }

    // Update Entities
    entitiesRef.current.forEach(entity => {
        // Movement Pattern
        entity.oscillationOffset += 0.05;
        
        // Base velocity
        entity.position.x += entity.velocity.x * ENTITY_CONFIG[entity.type].speed;
        entity.position.y += entity.velocity.y * ENTITY_CONFIG[entity.type].speed;

        // Add Jitter/Curve
        if (entity.type === EntityType.MOSQUITO || entity.type === EntityType.BOSS) {
            entity.position.x += Math.sin(entity.oscillationOffset) * 2;
        } else if (entity.type === EntityType.BUTTERFLY) {
             entity.position.y += Math.cos(entity.oscillationOffset) * 1.5;
        }

        // Cleanup off-screen
        if (
            entity.position.x < -50 || 
            entity.position.x > canvas.width + 50 || 
            entity.position.y < -50 || 
            entity.position.y > canvas.height + 50
        ) {
            entity.isDead = true;
        }
    });

    // Collision Detection
    const batRadius = 40; // Bat hit area
    const batX = batPosRef.current.x;
    const batY = batPosRef.current.y;

    entitiesRef.current.forEach(entity => {
        if (entity.isDead) return;

        const dx = entity.position.x - batX;
        const dy = entity.position.y - batY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < batRadius + entity.radius) {
            handleCollision(entity);
        }
    });

    // Filter dead entities
    entitiesRef.current = entitiesRef.current.filter(e => !e.isDead);

    // Update Particles
    particlesRef.current.forEach(p => {
        p.position.x += p.velocity.x;
        p.position.y += p.velocity.y;
        p.life -= 0.02;
    });
    particlesRef.current = particlesRef.current.filter(p => p.life > 0);

    // Update Floating Text
    textsRef.current.forEach(t => {
        t.position.y -= 1; // Float up
        t.life -= 0.02;
    });
    textsRef.current = textsRef.current.filter(t => t.life > 0);
  };

  const spawnEntity = (canvas: HTMLCanvasElement) => {
      const edge = Math.floor(Math.random() * 4); // 0: top, 1: right, 2: bottom, 3: left
      let x = 0, y = 0, vx = 0, vy = 0;
      
      // Determine spawn position and velocity (towards center generally)
      const targetX = Math.random() * canvas.width;
      const targetY = Math.random() * canvas.height;

      switch(edge) {
          case 0: x = Math.random() * canvas.width; y = -40; break;
          case 1: x = canvas.width + 40; y = Math.random() * canvas.height; break;
          case 2: x = Math.random() * canvas.width; y = canvas.height + 40; break;
          case 3: x = -40; y = Math.random() * canvas.height; break;
      }

      // Calculate normalized vector to target
      const angle = Math.atan2(targetY - y, targetX - x);
      vx = Math.cos(angle);
      vy = Math.sin(angle);

      // Randomize Type
      const rand = Math.random();
      let type = EntityType.MOSQUITO;
      
      if (rand > 0.95) type = EntityType.BOSS;
      else if (rand > 0.85) type = EntityType.BEE;
      else if (rand > 0.75) type = EntityType.LADYBUG;
      else if (rand > 0.65) type = EntityType.BUTTERFLY;

      const config = ENTITY_CONFIG[type];

      entitiesRef.current.push({
          id: Math.random().toString(36),
          type,
          position: { x, y },
          velocity: { x: vx, y: vy },
          radius: config.radius,
          rotation: 0,
          points: config.score,
          isDead: false,
          spawnTime: Date.now(),
          oscillationOffset: Math.random() * Math.PI * 2
      });
  };

  const handleCollision = (entity: Entity) => {
      const config = ENTITY_CONFIG[entity.type];

      if (config.isDangerous) {
          audioService.playGameOver();
          onGameOver(scoreRef.current);
          return;
      }

      // It's a kill
      entity.isDead = true;
      audioService.playSplat();
      createBloodSplatter(entity.position.x, entity.position.y, config.color);
      
      // Scoring & Combo
      const now = Date.now();
      if (now - lastKillTimeRef.current < GAME_CONFIG.COMBO_WINDOW) {
          comboCountRef.current++;
      } else {
          comboCountRef.current = 1;
      }
      lastKillTimeRef.current = now;

      let points = config.score;
      if (comboCountRef.current >= GAME_CONFIG.COMBO_THRESHOLD) {
          points += GAME_CONFIG.SCORE_COMBO_BONUS;
          createFloatingText("COMBO!", entity.position.x, entity.position.y - 20, '#FFD700');
          audioService.playBonus();
          // Reset combo slightly to require rapid hits again or keep stacking?
          // Let's keep stacking but only show text every 3
          if (comboCountRef.current % 3 === 0) {
            // Extra visual flair could go here
          }
      } else {
          createFloatingText(`+${points}`, entity.position.x, entity.position.y - 20, '#FFF');
      }

      scoreRef.current += points;
      setInternalScore(scoreRef.current);
      onScoreUpdate(scoreRef.current);
  };

  const createBloodSplatter = (x: number, y: number, color: string) => {
      for (let i = 0; i < 8; i++) {
          particlesRef.current.push({
              id: Math.random().toString(),
              position: { x, y },
              velocity: { x: (Math.random() - 0.5) * 5, y: (Math.random() - 0.5) * 5 },
              life: 1.0,
              color: color,
              size: Math.random() * 5 + 2
          });
      }
      // Add a stain that stays longer (simulated by a very slow fading particle)
       particlesRef.current.push({
            id: Math.random().toString(),
            position: { x, y },
            velocity: { x: 0, y: 0 },
            life: 3.0, // Lasts longer
            color: color,
            size: 15
        });
  };

  const createFloatingText = (text: string, x: number, y: number, color: string) => {
      textsRef.current.push({
          id: Math.random().toString(),
          text,
          position: { x, y },
          life: 1.0,
          color
      });
  };

  // --- Drawing Functions ---

  const drawEntities = (ctx: CanvasRenderingContext2D) => {
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      entitiesRef.current.forEach(entity => {
          const config = ENTITY_CONFIG[entity.type];
          
          // Draw shadow
          ctx.font = `${config.radius * 2}px serif`;
          ctx.fillStyle = 'rgba(0,0,0,0.3)';
          ctx.fillText(config.emoji, entity.position.x + 5, entity.position.y + 5);

          // Draw Entity
          ctx.fillStyle = 'black'; // fallback
          ctx.fillText(config.emoji, entity.position.x, entity.position.y);
          
          // Debug circle
          // ctx.beginPath();
          // ctx.strokeStyle = 'red';
          // ctx.arc(entity.position.x, entity.position.y, entity.radius, 0, Math.PI*2);
          // ctx.stroke();
      });
  };

  const drawParticles = (ctx: CanvasRenderingContext2D) => {
      particlesRef.current.forEach(p => {
          ctx.globalAlpha = p.life;
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.position.x, p.position.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.globalAlpha = 1.0;
      });
  };

  const drawFloatingText = (ctx: CanvasRenderingContext2D) => {
      ctx.font = "bold 24px 'Bangers'";
      textsRef.current.forEach(t => {
          ctx.globalAlpha = t.life;
          ctx.fillStyle = 'black';
          ctx.fillText(t.text, t.position.x + 2, t.position.y + 2); // Shadow
          ctx.fillStyle = t.color;
          ctx.fillText(t.text, t.position.x, t.position.y);
          ctx.globalAlpha = 1.0;
      });
  };

  const drawBat = (ctx: CanvasRenderingContext2D, x: number, y: number, rotation: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(rotation);

      // Handle
      ctx.fillStyle = '#8B4513';
      ctx.fillRect(-5, 0, 10, 80);

      // Swatter Mesh
      ctx.beginPath();
      ctx.fillStyle = 'rgba(200, 200, 200, 0.5)';
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 3;
      
      // Draw a squarish rounded shape
      ctx.roundRect(-40, -90, 80, 90, 20);
      ctx.fill();
      ctx.stroke();

      // Mesh Grid
      ctx.strokeStyle = 'rgba(50, 50, 50, 0.3)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for(let i=-35; i<40; i+=10) {
          ctx.moveTo(i, -90);
          ctx.lineTo(i, 0);
      }
      for(let i=-85; i<0; i+=10) {
          ctx.moveTo(-40, i);
          ctx.lineTo(40, i);
      }
      ctx.stroke();

      // Lightning/Electric Icon (optional flair)
      ctx.fillStyle = '#FFD700';
      ctx.font = '24px Arial';
      ctx.fillText('⚡', -12, -45);

      ctx.restore();
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  });

  return (
    <canvas
      ref={canvasRef}
      className={`block absolute top-0 left-0 w-full h-full game-cursor-hidden`}
    />
  );
};

export default GameCanvas;