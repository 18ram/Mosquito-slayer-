import React from 'react';
import { GameState } from '../types';

interface UIOverlayProps {
  gameState: GameState;
  score: number;
  highScore: number;
  onStart: () => void;
  onRestart: () => void;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ gameState, score, highScore, onStart, onRestart }) => {
  if (gameState === GameState.PLAYING) {
    return (
      <div className="absolute top-4 left-4 pointer-events-none select-none z-10">
        <div className="font-arcade text-4xl text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
          SCORE: {score}
        </div>
      </div>
    );
  }

  if (gameState === GameState.START) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 z-20 backdrop-blur-sm">
        <h1 className="font-arcade text-7xl text-yellow-400 mb-4 drop-shadow-lg tracking-wider text-center">
          MOSQUITO MAYHEM
        </h1>
        <p className="text-white text-xl mb-8 font-bold">Swat the mosquitoes 🦟. Avoid the friendly bugs 🐝.</p>
        <button
          onClick={onStart}
          className="px-8 py-4 bg-green-600 hover:bg-green-500 text-white font-arcade text-3xl rounded-lg shadow-xl transition transform hover:scale-105 active:scale-95 border-b-4 border-green-800"
        >
          START GAME
        </button>
      </div>
    );
  }

  if (gameState === GameState.GAME_OVER) {
    return (
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-red-900/80 z-20 backdrop-blur-sm animate-fade-in">
        <h2 className="font-arcade text-8xl text-white mb-2 drop-shadow-[0_5px_5px_rgba(0,0,0,1)]">
          GAME OVER
        </h2>
        <div className="bg-white/10 p-8 rounded-xl backdrop-blur-md border border-white/20 flex flex-col items-center mb-8">
            <p className="font-arcade text-4xl text-yellow-300 mb-2">Final Score: {score}</p>
            <p className="text-white text-lg font-bold">High Score: {highScore}</p>
        </div>
        
        <button
          onClick={onRestart}
          className="px-8 py-4 bg-yellow-500 hover:bg-yellow-400 text-black font-arcade text-3xl rounded-lg shadow-xl transition transform hover:scale-105 active:scale-95 border-b-4 border-yellow-700"
        >
          TRY AGAIN
        </button>
      </div>
    );
  }

  return null;
};

export default UIOverlay;